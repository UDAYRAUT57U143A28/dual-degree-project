package com.example.myapplicationregistration;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends Activity {

    private String predefinedUsername  = "user";
    private String predefinedPassword = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText username = findViewById(R.id.etUsername);
        EditText password = findViewById(R.id.etPassword);
        Button loginButton= findViewById(R.id.btnLogin);

        loginButton.setOnClickListener(view -> {
            String correctUsername = username.getText().toString();
            String correctPassword = password.getText().toString();

            if (username.getText().toString().equals(correctUsername) &&
                    password.getText().toString().equals(correctPassword)) {
                Intent intent = new Intent(login.this, WelcomeActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(this,"invalid info",Toast.LENGTH_SHORT).show();
            }

        });


    }


}