package com.example.myapplicationregistration;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class activityRegistration extends Activity {

    private EditText name;
    private EditText username;
    private EditText password;
    private EditText confirmPassword;
    private EditText age;
    private EditText phone;
    private EditText gender;
    private EditText city;
    private EditText country;
    private EditText state,address;
    public Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name = findViewById(R.id.name);
        username = findViewById(R.id.username);
        password= findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirm_password);
        age = findViewById(R.id.age);
        phone = findViewById(R.id.phone);
        gender = findViewById(R.id.gender);
        city = findViewById(R.id.city);
        country = findViewById(R.id.country);
        state = findViewById(R.id.state);
        address = findViewById(R.id.address);
        register = findViewById(R.id.register);

        register.setOnClickListener(view -> registerUser());
        register.setOnClickListener(view -> {
            Intent intent = new Intent( activityRegistration.this, login.class );
            intent.putExtra("username", username.getText().toString());
            intent.putExtra("password", password.getText().toString());
            startActivity(intent);
        });
    }


    private void registerUser(){
        String userName = name.getText().toString().trim();
        String userUsername = username.getText().toString().trim();
        String userPassword = password.getText().toString().trim();
        String userConfirmPassword = confirmPassword.getText().toString().trim();
        String userAge = age.getText().toString().trim();
        String userPhone = phone.getText().toString().trim();
        String userGender = gender.getText().toString().trim();
        String userCity = city.getText().toString().trim();
        String userCountry = country.getText().toString().trim();
        String userState =state.getText().toString().trim();
        String userAddress = address.getText().toString().trim();

        if(TextUtils.isEmpty(userName) || TextUtils.isEmpty(userUsername) || TextUtils.isEmpty(userPassword)
                || TextUtils.isEmpty(userConfirmPassword) || TextUtils.isEmpty(userAge)|| TextUtils.isEmpty(userPhone)
                || TextUtils.isEmpty(userGender) || TextUtils.isEmpty(userCity)|| TextUtils.isEmpty(userCountry)
                || TextUtils.isEmpty(userState)|| TextUtils.isEmpty(userAddress)){
            Toast.makeText(this, "Please fill all Fields",Toast.LENGTH_SHORT).show();
            return;
        }

        if (!userPassword.equals(userConfirmPassword)){
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;

        }

        Toast.makeText(this," User registered successfully", Toast.LENGTH_SHORT).show();


    }


}
